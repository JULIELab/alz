---
datecreated: '2019-09-21T09:47:35.803Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d78a7df4-dc54-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502013-00462-list.json
tags: []
---
Die zur Verbeſſerung ſeiner traurigen
Umſtände kürzlich noch auf Pränumeration von ihm an-
gekündigten Kleinigkeiten meiſt romantiſchen Innhalts kön-
nen alſo nun nicht erſcheinen, daher die Pränumeranten
ihr Geld bey den reſp. Collecteurs zurückfodern mö-
gen.