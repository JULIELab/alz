---
datecreated: '2019-09-21T08:48:39.535Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/9bc56fc0-dc4c-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00283-list.json
tags: []
---
Der Ausgang wird auch ſo-
wohl durch den Spieler, der allen Gewinn zurück,
und dem, von dem er gewonnen, ſo viel gute Lehren
giebt, als durch die Entdeckung, daſs dies Amaliens
Vater iſt, ſehr romantiſch.