---
datecreated: '2019-09-21T09:03:30.501Z'
datemodified: '2019-09-21T09:03:57.303Z'
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/af5bddd8-dc4e-11e9-a70b-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00499-list.json
tags: []
---
Von den neuen romantiſchen Erzählungen,
denen der Zuſatz: aus dem Geiſterreiche, auf dem Ti-
tel vermuthlich nur zur Lockſpeiſe angehängt worden
iſt, erſcheint hier das erſte Bändchen.