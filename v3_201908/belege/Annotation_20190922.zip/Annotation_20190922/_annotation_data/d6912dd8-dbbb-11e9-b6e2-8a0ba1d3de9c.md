---
datecreated: '2019-09-20T15:32:21.230Z'
datemodified: '2019-09-20T15:39:07.493Z'
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d6912dd8-dbbb-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10501968-00180-list.json
tags: []
---
Und dem romantiſch gethürmten Aetna;