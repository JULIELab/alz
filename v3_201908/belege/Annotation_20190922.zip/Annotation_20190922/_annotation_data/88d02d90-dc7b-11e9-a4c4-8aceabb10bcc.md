---
datecreated: '2019-09-21T14:24:34.104Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/88d02d90-dc7b-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00444-list.json
tags: []
---
In
derſelben Rückſicht iſt die romantiſche Narrative of
the Loſs of the Ship Hercules commanded by Capt. Bj.
Stout, – on the Coaſt of Caffraria 18 Jun. 1796 etc.
L. Johnſon 1798. 112 S. 8. (3 ſh.) intereſſant; ſie ent-
hält zugleich Beweiſe, daſs ſogenannte Wilden oft
durch ihr Betragen aufgeklärte Europäer beſchämen.