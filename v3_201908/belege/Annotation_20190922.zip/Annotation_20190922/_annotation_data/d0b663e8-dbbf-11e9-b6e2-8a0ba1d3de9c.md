---
datecreated: '2019-09-20T16:00:49.336Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d0b663e8-dbbf-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502001-00248-list.json
tags: []
---
Der Boden dieſes romantiſch
ſchönen Landes umher, iſt das Grab ehemals berühm-
ter römiſcher Städte, wovon ſich die Spuren häufig auf
der Oberfläche zeigen.