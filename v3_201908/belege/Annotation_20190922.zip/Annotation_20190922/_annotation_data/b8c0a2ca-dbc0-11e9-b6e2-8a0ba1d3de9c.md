---
datecreated: '2019-09-20T16:07:18.631Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/b8c0a2ca-dbc0-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502001-00343-list.json
tags: []
---
Hier krönt
Das ſchöne Paradies mit grünender
Umwallung eingefaſst, die flache Stirn
des ſteil gethürmten Berges, der ringsum
mit Dickicht und Gebüſch romantiſch wild
bewachſen, allen Zugang wehrt.