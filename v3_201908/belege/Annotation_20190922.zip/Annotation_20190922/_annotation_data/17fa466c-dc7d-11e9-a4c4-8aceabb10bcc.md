---
datecreated: '2019-09-21T14:35:43.777Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/17fa466c-dc7d-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00599-list.json
tags: []
---
Es enthält von dem Dörfchen Plauen, bis zu
den Ruinen von Tharant, wo es ſich ſchlieſst, in
einer Länge von drittehalb Stunden, die ein ſchnel-
ler Waldbach durchläuft, eine Mannichfaltigkeit von
engen und weiten, von kahlen und bewachſenen Fel-
ſen, von Laub- und Schwarzholz, von Mühlen und
Dörfern, von Hütten und Weinbergen, von roman-
tiſchen und ländlichen Parthieen, daſs der Anblick
dieſer abwechſelnden Scenen in das angenehmſte Er-
ſtaunen verſetzt.