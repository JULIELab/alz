---
datecreated: '2019-09-21T09:11:06.330Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/be53a478-dc4f-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00637-list.json
tags: []
---
Allerley, romantiſches. II, 51.