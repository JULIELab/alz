---
datecreated: '2019-09-21T14:25:49.418Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/b5b4af98-dc7b-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00477-list.json
tags: []
---
Aurora, ein romantiſches Gemälde der Vorzeit vom
Vf. des Rinaldini, 1r Theil 3te umgearb. Aufl. Leip-
zig 800. 12.