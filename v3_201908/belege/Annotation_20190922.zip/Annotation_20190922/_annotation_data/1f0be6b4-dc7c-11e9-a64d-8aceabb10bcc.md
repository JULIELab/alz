---
datecreated: '2019-09-21T14:28:46.120Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/1f0be6b4-dc7c-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00512-list.json
tags: []
---
Ein ſchätzbarer Beytrag zu den immer ſeltener wer-
denden Schriften, romantiſchen Inhalts, die die Ver-
nunft und das Herz mit gleichem Wohlgefallen zu le-
ſen verſtatten.