---
datecreated: '2019-09-21T14:05:39.590Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/e4a181bc-dc78-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00346-list.json
tags: []
---
Oder foll romantiſch etwan
nicht mehr bedeuten als pragmatiſch?