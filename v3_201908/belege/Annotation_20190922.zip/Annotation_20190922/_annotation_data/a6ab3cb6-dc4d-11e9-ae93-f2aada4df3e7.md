---
datecreated: '2019-09-21T08:56:07.628Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/a6ab3cb6-dc4d-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00409-list.json
tags:
- IR
---
Beluſtigungen, chiromantiſche 347, 319