---
datecreated: '2019-09-21T14:52:28.688Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/6efa504a-dc7f-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00683-list.json
tags: []
---
Der Engländer theilt die ſeinigen
im Allgemeinen in Romances, oder pathetiſche, wie die
Helden und Ritterromane, Geiſtergeſchichten u. ſ. w.
kurz romantiſche Geſchichten aus der Vorzeit oder aus
einer erdichteten Welt, und in Novels, deren Stoff
aus den gegenwärtigen Zeiten hergenommen iſt,
Familien und ſogenannte Liebesgeſchichten, wie
die Rubrik ehedem in unſern Buchhandler-Ca-
talogen lautete, die ſich indeſſen zuweilen durch ih-
ren Ton zu den pathetiſchen erheben.