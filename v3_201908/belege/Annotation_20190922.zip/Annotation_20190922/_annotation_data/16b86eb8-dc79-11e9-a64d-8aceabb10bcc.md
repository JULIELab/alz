---
datecreated: '2019-09-21T14:07:03.666Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/16b86eb8-dc79-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00371-list.json
tags: []
---
a) Aurora. Ein romantiſches Gemälde der Vorzeit. In
6 Büchern oder 2 Thl. Mit 6 Kupfern, 3te verbeſſerte
und verſchönerte Auſlage. Taſchenformat broch. 2
Rthl. 16 gr.