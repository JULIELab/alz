---
datecreated: '2019-09-21T14:43:20.071Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/27f658ca-dc7e-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00607-list.json
tags: []
---
von Phänomenen, wie ſie in der Seele eines Blind-
gebornen vor ſeiner Heilung vorfallen können, den
Anſpruch auf eine Stelle in jener Claſſe von Geiſtes-
producten ſtreitig machen.