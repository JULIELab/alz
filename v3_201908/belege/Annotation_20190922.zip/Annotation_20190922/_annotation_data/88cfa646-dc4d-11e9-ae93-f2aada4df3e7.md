---
datecreated: '2019-09-21T08:55:17.179Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/88cfa646-dc4d-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00342-list.json
tags: []
---
aber es hat doch bey einem
groſsen Theil des Publikums durch das romantiſche und
fremdartige ſeiner Situationen ſehr gefallen, und es ſind
ſchon wieder ein paar andre Sujets aus dem Oſſian unter
der Arbeit.