---
datecreated: '2019-09-20T15:57:07.926Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/4cbf8bc8-dbbf-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502001-00117-list.json
tags: []
---
Nr. 8. Dieſe Sammlung romantiſchen Auswurfs
wird immer noch raſch fortgeſetzt: leider, ein Beweis,
daſs es ihr nicht an Käufern und Leſern fehlt, zugleich
aber auch ein Beweis über alle Beweiſe, daſs der Schluſs
von dem Abſatz eines Buchs auf ſeinen Werth durchaus
unſtatthaft, und nichts lächerlicher iſt, als das Pochen
gewiſſer mittelmäſsiger und ſchlechter Scribenten, die
eben durch ihre Geiſtesarmuth ſich den Beyfall des gro-
ſen Haufens erworben haben, und die nun das Verdam-
mungsurtheil der Kunſtrichter durch die Zufriedenheit
ihrer Verleger niederzuſchlagen meyen.