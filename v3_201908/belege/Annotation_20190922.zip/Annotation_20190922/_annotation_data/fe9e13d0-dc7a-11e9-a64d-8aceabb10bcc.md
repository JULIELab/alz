---
datecreated: '2019-09-21T14:20:42.224Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/fe9e13d0-dc7a-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00402-list.json
tags: []
---
Wir glauben den Inhalt dieſer kleinen philoſophiſch-
romantiſchen Schrift nicht beſſer angeben und ihren
Geiſt nicht beſſer charakteriſiren zu können, als mit
den eignen Worten des Verfaſſers in der Vorrede :
"Sie enthält die abſichtloſen ungekünſtelten Ergieſsun-
gen eines gefühlvollen Herzens, denen ſich in einer
Stunde der Erinnerung und des Nachgenuſſes eines
ſchönen Tages ungeſucht die Worte darboten, um
auch dem entfernten Bruderherzen vernehmbar werden
zu können."