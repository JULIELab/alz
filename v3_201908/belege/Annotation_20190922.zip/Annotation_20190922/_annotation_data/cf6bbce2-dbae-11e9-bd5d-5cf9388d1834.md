---
datecreated: '2019-09-20T13:59:06.191Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="/annotate/annotations/cf6bbce2-dbae-11e9-bd5d-5cf9388d1834.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10501990-00384-list.json
tags: []
---
Eine vertraue Bekanntſchaft mit dem Dichter ſelbſt,
der einſt in dieſen romantiſchen Gegenden mehrere ſeiner ſchön
ften Lieder ſang, ein ähnliches Gefühl für die Schönheiten und
Freuden der Natur, leuchten allenthalben in dieſem kleinen Ge-
dichte hervor.