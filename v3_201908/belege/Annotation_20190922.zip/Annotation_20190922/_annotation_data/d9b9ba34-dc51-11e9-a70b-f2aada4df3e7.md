---
datecreated: '2019-09-21T09:26:10.982Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d9b9ba34-dc51-11e9-a70b-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502013-00199-list.json
tags: []
---
Verſuch, jener Strenge auszuweichen; genug, wenn
dieſe Ausweichung, wie das oft der Fall war, auf
einen noch unbetretenen Nebenweg führte, den dich-
teriſchen Gebiete mehr Boden gewann, und einen er-
weiterten, reichern Anbau deſſelben veranlaſste.
Unſre dramatiſchen und romantiſchen Dichtungen
z. B. haben unſtreitig dadurch gewonnen, daſs man
in jenen von den geſetzlichen Beſchränkungen der tra-
giſchen und komiſchen Gattung auswich, und daſs
man in dieſen ſich nicht immer an die Darſtellung
einer einzigen Hauptperſon feſthielt.