---
datecreated: '2019-09-20T15:29:05.944Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/622e4f8e-dbbb-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502000-00423-list.json
tags: []
---
Erzählungen, zwey romantiſche, 1) die ſchöne Rhein-
länderin, 2) der Brief eines Ungenannten. 8. 7 gr.