---
datecreated: '2019-09-21T09:42:46.211Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/2aefa5e2-dc54-11e9-a70b-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502013-00448-list.json
tags: []
---
Das Fürſtenthum Schwarzburg
ſcheint beyde Vorzüge in ſich zu vereinigen, indem es
nicht nur, wie überhaupt ganz Thüringen, zu den an-
gebauteſten Theilen von Deutſchland gehört, ſondern
auch nach ſeiner natürlichen Lage auf der einen Seite
mit dem Fichtelgebirge und dem Thüringer Walde, auf
der andern mit dem Harze im nahen Zuſammenhange
ſteht, und in dieſer Lage eben ſowohl rauhe, einfache
Waldgegenden, als auch angenehme, romantiſche, und
durch einen mannichfaltigen Anbau verſchönerte Thäler
und Ebenen, welche die Saale, die Loquiz und die
Schwarze, die Ilm, Wipper und Helm durchwäſſern,
aufzeigen kann.