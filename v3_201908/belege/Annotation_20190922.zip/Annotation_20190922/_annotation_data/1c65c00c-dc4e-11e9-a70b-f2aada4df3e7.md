---
datecreated: '2019-09-21T08:59:24.846Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/1c65c00c-dc4e-11e9-a70b-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00475-list.json
tags: []
---
RIGA u. LEIPZIG, b. Müller: Romantiſche Plaiſan-
terien. 1796. 288 S. 8. (15 gr.)