---
datecreated: '2019-09-21T14:39:04.528Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/8fa4cae8-dc7d-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00600-list.json
tags: []
---
Zwar geſtatten ihm dieſe Gebirge mit jenen,
immer als höher gedachten, keine Vergleichung, aber
der Anblick in dieſer Nähe der Stadt, und mitten in
einer fruchtbaren Berglehne, die ſich wie durch einen
Zauberſchlag öffnet, um ihn plötzlich in eine roman-