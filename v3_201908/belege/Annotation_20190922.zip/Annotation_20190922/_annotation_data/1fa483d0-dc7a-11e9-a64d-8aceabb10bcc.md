---
datecreated: '2019-09-21T14:14:28.134Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/1fa483d0-dc7a-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00372-list.json
tags: []
---
Rinaldo Rinaldini. Der Räuber-Hauptman. Eine ro-
mantiſche Geſchichte unſers Jahrhunderts. 3r Thl als
der letzte von der 3ten verbeſſerten Auflage, welcher
5 Bücher der erſtern Auſlagen enthält. Mit 5 Kup-
fern 8. brochirt wird als Reſt zur den 1ten u. 2ten Thle
der 3ten Auflage den Käufern gratis nachgeliefert. Die
3 Thle mit 15 Kupfern koſten 4 Rthl. und ohne Kup-
fer 2 Rthl. 12 gr.