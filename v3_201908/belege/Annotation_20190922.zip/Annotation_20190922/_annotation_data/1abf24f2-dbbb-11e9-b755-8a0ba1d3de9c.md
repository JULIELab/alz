---
datecreated: '2019-09-20T15:27:06.156Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/1abf24f2-dbbb-11e9-b755-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10501968-00136-list.json
tags: []
---
Wir wiſſen nicht, ob keine Stücke eingekom-
men, oder ob die Sache durch Leſſing's Tod in Ver-
geſſenheit gerathen, genug das Publikum hat von
dem Erfolg dieſer Preisausſetzung weiter nichts er-
fahren, auſser daſs Herr Mag. Krauſe in den Halle
1784 herausgegebenen romantiſchen Erzählungen
eine Erzählung über dieſes Sujet hat, die, wie er
ſagt, aus einem von ihm bey dieſer Gelegenheit
entworfnen Drama entſtanden iſt.