---
datecreated: '2019-09-20T15:14:34.803Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/5aed08ac-dbb9-11e9-b755-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10501967-00200-list.json
tags: []
---
Dies iſt im Kurzen die Skizze dieſes proſaiſchen
Gedichts, das im Detail überaus viel Romantiſches
hat, und die Einbildungskraft des Leſers ſehr an-
genehm beſchäftiget.