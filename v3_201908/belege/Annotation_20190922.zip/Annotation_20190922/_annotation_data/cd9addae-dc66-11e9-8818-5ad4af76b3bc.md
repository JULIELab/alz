---
datecreated: '2019-09-21T11:56:10.045Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/cd9addae-dc66-11e9-8818-5ad4af76b3bc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502015-00384-list.json
tags: []
---
Übungen im Zeichnen, Tuſchen und Coloriren, roman-
tiſcher Scenen. 4. 1 Rthlr.
Leipzig, 1798.