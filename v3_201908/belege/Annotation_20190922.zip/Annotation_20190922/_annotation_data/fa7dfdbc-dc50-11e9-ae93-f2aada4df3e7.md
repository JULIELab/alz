---
datecreated: '2019-09-21T09:19:56.411Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/fa7dfdbc-dc50-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502013-00124-list.json
tags: []
---
ſo leidet das Gemälde ſchon
nothwendig eine Verfälſchung, und es iſt zu fürch-
ten, daſs eine weit ſchädlichere Anſicht der Geſchich-
te dadurch befördert werde, als die gänzlich ro-
mantiſche iſt, nämlich eine empfindſame.