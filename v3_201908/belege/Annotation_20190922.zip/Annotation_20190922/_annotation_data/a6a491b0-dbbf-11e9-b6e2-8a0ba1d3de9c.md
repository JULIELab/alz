---
datecreated: '2019-09-20T15:59:38.762Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/a6a491b0-dbbf-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502001-00148-list.json
tags: []
---
W. Thornborough, the benevolent Quixote (Lond. 4. Voll.
1791.) gehört unter dieſe wenigen, und iſt unſtreitig
das Werk eines Mannes von Geiſt, Weltkenntniſs und
romantiſchen Genie.