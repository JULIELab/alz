---
datecreated: '2019-09-21T13:56:25.734Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/9e2d3af6-dc77-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00345-list.json
tags: []
---
LEIPZIG, in d. Höferſchen Buchh.: Lombardiſche
Gemälde, hiſtoriſch-romantifch bearbeitet von
Schlenkert. 1ſter Theil. 1796. 448 S. 8. (1 Rthlr.
16 gr.)