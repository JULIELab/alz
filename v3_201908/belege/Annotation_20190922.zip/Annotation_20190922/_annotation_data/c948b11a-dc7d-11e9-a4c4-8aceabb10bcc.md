---
datecreated: '2019-09-21T14:40:41.562Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/c948b11a-dc7d-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00607-list.json
tags: []
---
DANZIG, b. Troſchel: Romantiſche Ausſtellungen.
Von dem Verfaſſer der grauen Mappe. Erſter
Band. 1797. 332 S. 8.