---
datecreated: '2019-09-20T16:00:57.929Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d5ca6438-dbbf-11e9-b6e2-8a0ba1d3de9c.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10501969-00250-list.json
tags: []
---
Der Felſen der Verliebten, S. 127. (wo Ar-
naud wieder der vorige, nemlich der Erzähler einer
unglücklichen romantiſchen Liebe iſt)