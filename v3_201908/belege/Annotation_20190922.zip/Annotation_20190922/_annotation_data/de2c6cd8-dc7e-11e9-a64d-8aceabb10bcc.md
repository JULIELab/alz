---
datecreated: '2019-09-21T14:48:25.801Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/de2c6cd8-dc7e-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00671-list.json
tags: []
---
Dadurch nicht allein, ſondern auch durch die reizende
Mannichfaltigkeit, welche aus der Form des Brief-
wechſels zwiſchen ſo verſchiedenen intereſſanten Per-
ſonen entſtehet, vornehmlich aber durch die Eigen-
thümlichkeiten des Ariſtippiſchen Geiſtes, der aus Scharf-
ſinn, Witz und frohem Spott zuſammengeſetzt, durch
Kenntniſſe aller Art genährt, durch Wahrheitsliebe und
Humanität geleitet iſt, unterſcheidet ſich der Wielan-
diſche Ariſtipp von der romantiſchen Schilderung Grie-
chenlands in der Reiſe des jüngern Anacharſis.