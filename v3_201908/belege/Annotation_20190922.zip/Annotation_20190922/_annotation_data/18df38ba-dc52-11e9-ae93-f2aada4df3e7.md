---
datecreated: '2019-09-21T09:27:56.913Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/18df38ba-dc52-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502013-00205-list.json
tags: []
---
Die Gegend um Smirna iſt romantiſch
ſchön; der ungemein fruchtbare Boden kommt der
unbezwinglichen Indolenz der Türken zu Hülfe: er
fodert wenig Cultur zur Hervorbringung des ſchön-
ſten Getreides und Obſtes.