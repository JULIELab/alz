---
datecreated: '2019-09-21T08:57:31.346Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d8c4aebc-dc4d-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00435-list.json
tags: []
---
3) BRAUNSCHWEIG, b. Schröder: Die Aſſeburg. Hiſto-
riſch-romantiſches Gemälde. Dramatiſirt. 1796.
8. (1 Rthlr. 4 gr.)