---
datecreated: '2019-09-21T14:32:18.147Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/9d6b2b3c-dc7c-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00599-list.json
tags: []
---
Er nahm nämlich an, daſs der ganze
plauiſche Grund vom Eingange an, bis an die Rui-
nen von Tharant, mit ſeinen in der Tiefe, und auf
den Höhen gelegenen Rittergütern und Dörfern eine
einzige Herrſchaft wäre, und einem geſchmackvollem
Beſitzer gehörte, und legte ſich nun ſelbſt die Auf-
gabe vor, wie derſelbe ohne beträchtliche Verminde-
rung des Ertrages zu einen romantiſchen Paradieſe
erhoben werden könnte.