---
datecreated: '2019-09-21T14:56:09.230Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/f23a3f92-dc7f-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00691-list.json
tags: []
---
Ausſtellungen, romantiſche, v. d. Verf. d. grau-
en Mappe, 1 B. 279, 745.