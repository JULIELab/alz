---
datecreated: '2019-09-21T14:11:55.313Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/c48faf60-dc79-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00372-list.json
tags: []
---
Von Rinaldo Rinaldini. Der Hiäuber-Hauptmann. Eine
romantiſche Geſchichte unſers Jahrhunderts
ſind nun alle 3 Bde der 3ten verbeſſerten Auflage fertig.