---
datecreated: '2019-09-21T14:55:11.364Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/cfebe300-dc7f-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00690-list.json
tags: []
---
Auf beiden Blättern findet man
eine täuſchende Darſtellung der romantiſchen Gegenden,
welche Pillnitz umgeben.