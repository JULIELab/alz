---
datecreated: '2019-09-21T12:32:08.528Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/d42d7a5a-dc6b-11e9-a14b-5ad4af76b3bc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502018-00216-list.json
tags: []
---
Unter dem angeblichen Druckort: MAYLAND: Fahr-
ten Sebaſtians von Fahrmann, ein charakteriſtiſch,
komiſch, moraliſch, romantiſcher, politiſcher Ro-
man, und was ſonſt noch Jeder – will. Vom
Verfaſſer der ſieben wunderbaren Lebensjahre
eines Kosmopoliten. 1798. Erſter Theil. 506 S.
Zweyter Theil. 352 S. 8. (2 Rthlr. 12 gr.)