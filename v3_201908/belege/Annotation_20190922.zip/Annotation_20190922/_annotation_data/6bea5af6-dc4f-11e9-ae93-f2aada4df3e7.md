---
datecreated: '2019-09-21T09:08:47.719Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/6bea5af6-dc4f-11e9-ae93-f2aada4df3e7.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502008-00598-list.json
tags: []
---
Eine geſchmackvolle
Auswahl von Gedichten und mehrere poetiſche Aufſätze,
mehrentheils romantiſchen Innhalts, haben vorzüglichen
Anſpruch auf den Beyfall des ſchönen Geſchlechts, in
Rückſicht eines weiſen Wechſels zwiſchen dem Angeneh-
men und Nützlichen.