---
datecreated: '2019-09-21T14:42:03.373Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/fa3fae68-dc7d-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00607-list.json
tags: []
---
Wenn man hiernächſt epi-
grammatiſche Schürzung und Löſung des Knotens
nothwendig zu romantiſchen Dichtungen fodert: ſo
könnte man freylich dieſer Darſtellung einer Reihe