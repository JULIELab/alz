---
datecreated: '2019-09-21T14:04:10.939Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/affb4ab0-dc78-11e9-a4c4-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00346-list.json
tags: []
---
Nicht zu geden-
ken, daſs nach dem richtigern Sprachgebrauche noch
ein Unterſchied zwiſchen Romanendichtung, und
romantiſcher Dichtung iſt.