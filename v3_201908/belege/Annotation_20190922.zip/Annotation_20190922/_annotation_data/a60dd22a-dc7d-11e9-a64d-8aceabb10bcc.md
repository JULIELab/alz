---
datecreated: '2019-09-21T14:39:42.464Z'
datemodified: ''
imagescr: <iiif-annotation annotationurl="t-duan.github.io/annotate/annotations/a60dd22a-dc7d-11e9-a64d-8aceabb10bcc.json"
  styling="image_only:true"></iiif-annotation>
layout: searchview
listname: bsb10502019-00600-list.json
tags: []
---
tiſche Welt zu verſetzen – dieſer Anblick iſt äuſserſt
überraſchend.